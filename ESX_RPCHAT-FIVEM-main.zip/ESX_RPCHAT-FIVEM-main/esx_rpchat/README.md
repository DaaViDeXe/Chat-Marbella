ESX RPCHAT

/ooc Local /oop Local /msg id (Private Message) /ayuda Send global help /lsdp - /ems - /taxi - /bennys (Customs jobs advertisements) /me Local (Especial Desing) /do Local (Especial Desing)

Requeriments
es_extended Final version 1.1

Tienes la opcion de poner la carpeta chat y rpchat para que sea igual que la foto!

Instalation
Drop in resources/[gameplay]

In CFG put start chat start esx_rpchat

This is my first content I hope you enjoy it!

Clefas#8226